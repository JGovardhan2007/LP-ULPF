# Universal Log Preprocessing Framework (ULPF / WEED)
NTRO 26156 - Production Air-Gapped Release

Quickstart:
  docker-compose up -d
Access Console:
  http://localhost:8080
