Write-Host "[+] Starting Universal Log Preprocessing Framework (ULPF)..." -ForegroundColor Cyan
docker-compose up -d
Write-Host "[+] Web Console online at http://localhost:8080" -ForegroundColor Green
