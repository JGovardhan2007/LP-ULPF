#!/bin/bash
echo "[+] Starting Universal Log Preprocessing Framework (ULPF)..."
docker-compose up -d
echo "[+] Web Console online at http://localhost:8080"
